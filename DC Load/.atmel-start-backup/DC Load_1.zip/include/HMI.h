/*
 * HMI.h
 *
 * Created: 13.04.2019 23:17:33
 *  Author: Hotwater
 */ 

#include <avr/io.h>
#include <stdbool.h>

#include "HD44780.h"

#ifndef HMI_H_
#define HMI_H_

#define BUT0	0
#define BUT1	1
#define BUT2	2


void HMI_Initialize();

void HMI_Display_Current(uint16_t currentInMilliamperes);
void HMI_Display_Voltage(uint16_t voltageInMillivolts);
void HMI_Display_Power(uint16_t powerInMilliwatts);
void HMI_Display_Mode(uint8_t currentMode);

bool HMI_Is_Button_Pressed(uint8_t buttonNumber);


#endif /* HMI_H_ */