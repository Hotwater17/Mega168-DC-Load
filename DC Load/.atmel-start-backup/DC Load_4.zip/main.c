#include <atmel_start.h>
#include <avr/io.h>
#include <util/delay.h>

#include "driver_init.h"
#include "i2c_master.h"
#include "i2c_simple_master.h"

#include "DCLoad.h"
#include "MCP4725.h"
#include "HMI.h"



void User_DAC_I2C_Init();
void User_DAC_I2C_Write(const uint8_t deviceAddress, const uint8_t registerAddress, const uint8_t data);
uint8_t User_DAC_I2C_Read(const uint8_t deviceAddress, const uint8_t registerAddress);

void User_ADC_Init();
uint16_t User_ADC_Read(uint8_t channel);

int main(void)
{
	
	atmel_start_init();
	
	dac_config_t dac_init_config;
	
	dac_init_config.dacInitFunction = User_DAC_I2C_Init;
	dac_init_config.dacReadFunction = User_DAC_I2C_Read;
	dac_init_config.dacWriteFunction = User_DAC_I2C_Write;
	
	load_config_t  load_init_config;
	
	load_init_config.adcInitFunction = User_ADC_Init;
	load_init_config.adcReadFunction = User_ADC_Read;
	load_init_config.dacWriteFunction = MCP4725_Set_Voltage_Fast;
	load_init_config.currentChannel = LOAD_CURRENT_CHANNEL;
	load_init_config.voltageChannel = LOAD_VOLTAGE_CHANNEL;
	load_init_config.temperatureChannel = LOAD_TEMPERATURE_CHANNEL;
	
	load_params_t loadData;
	/* Initializes MCU, drivers and middleware */
	//atmel_start_init();
	DDRD = 0xF0;
	//I2C_0_init();
	//HMI_Initialize();
	//MCP4725_Initialize(dac_init_config);
	//Load_Initialize(load_init_config);
	//f
	
	/* Replace with your application code */
	while (1) 
	{
		/*
		if(BUT0_get_level() == false)
		{
			MCP4725_Set_Voltage_Fast(500);
		}
		else
		{
			MCP4725_Set_Voltage_Fast(2000);
		}
		*/
		//User_DAC_I2C_Write(0x69, 0x10, 0x01);
		PORTD ^= 0xF0;

		_delay_ms(10);

		
		//Load_Run(&loadData);
	}
}

/*
 *	@brief User 
 */
void User_DAC_I2C_Init()
{
	I2C_0_initialization();
}

void User_DAC_I2C_Write(const uint8_t deviceAddress, const uint8_t registerAddress, const uint8_t data)
{
	I2C_0_write1ByteRegister(deviceAddress, registerAddress, data);
}

uint8_t User_DAC_I2C_Read(const uint8_t deviceAddress, const uint8_t registerAddress)
{
	return I2C_0_read1ByteRegister(deviceAddress, registerAddress);
}

void User_ADC_Init()
{
	ADC_0_init();
	ADC_0_enable();
}

uint16_t User_ADC_Read(uint8_t channel)
{
	return ADC_0_get_conversion(channel);
}


//TODO: Design system architecture
//TODO: Check if everything initializes properly. If not, create your own initialization procedures.
//TODO: Draw out abstraction layer diagram.
//TODO: Import SD Card library (Petit Fat FS).
//TODO: Implement HMI functions(display and buttons).
//TODO: Implement Load functions.
//TODO: Add function pointers to HMI module

/*
	DONE:
	-Design system requirements
	-Create DAC IC library.
	-Import LCD library (Mirek or Radzio).
 */