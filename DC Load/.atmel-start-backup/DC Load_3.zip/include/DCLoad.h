/*
 * DCLoad.h
 *
 * Created: 13.04.2019 23:02:45
 *  Author: Hotwater
 */ 

#include <avr/io.h>

#include "MCP4725.h"

#ifndef DCLOAD_H_
#define DCLOAD_H_

#define LOAD_MODE_DISABLED 0 
#define LOAD_MODE_CC 1
#define LOAD_MODE_CP 2

#define LOAD_SHUNT_MILLIOHMS 500
#define LOAD_MILLIVOLTS_TO_CELCIUS 

#define LOAD_TEMPERATURE_CHANNEL 0
#define LOAD_CURRENT_CHANNEL 1
#define LOAD_VOLTAGE_CHANNEL 2

/* Function pointers */


/* Variables */

typedef struct
{
	uint16_t (*adcReadFunction)(const uint8_t channel);
	void (*adcInitFunction)();
	void (*dacWriteFunction)(const uint16_t voltageInMillivolts);
	
	uint8_t currentChannel;
	uint8_t voltageChannel;
	uint8_t temperatureChannel;
	
}load_config_t;

typedef struct  
{
	uint16_t current;
	uint16_t voltage;
	uint16_t temperature;
	uint32_t power;
}load_params_t;

load_config_t load_actual_config;

uint8_t loadMode;

uint16_t setMaxTemperature;
uint16_t setCurrent;
uint16_t setPower;

/* Function prototypes */
void Load_Initialize(load_config_t params);
void Load_Set_Current(const uint16_t currentInMilliamperes);
void Load_Set_Max_Temperature(const uint16_t temperatureInCelcius);
void Load_Set_Power(const uint16_t powerInMilliwatts);
void Load_Set_Mode(const uint8_t mode);
void Load_Run(load_params_t *paramsPtr);
	
uint16_t Load_Get_Current();
uint16_t Load_Get_Voltage();
uint16_t Load_Get_Temperature();
uint32_t Load_Get_Power();
	





#endif /* DCLOAD_H_ */