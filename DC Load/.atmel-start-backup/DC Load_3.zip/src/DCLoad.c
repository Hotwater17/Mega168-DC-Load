/*
 * DCLoad.c
 *
 * Created: 13.04.2019 23:02:31
 *  Author: Hotwater
 */ 

#include "DCLoad.h"

uint8_t loadMode = LOAD_MODE_DISABLED;

uint16_t setMaxTemperature = 0;
uint16_t setCurrent = 0;
uint16_t setPower = 0;

/*
 *	@brief Initializes load, sets ADC readout function and channel numbers
 *  @param 
 */
void Load_Initialize(load_config_t params)
{
	load_actual_config.adcReadFunction = params.adcReadFunction;
	load_actual_config.adcInitFunction = params.adcInitFunction;
	load_actual_config.dacWriteFunction = params.dacWriteFunction;
	
	load_actual_config.currentChannel = params.currentChannel;
	load_actual_config.temperatureChannel = params.temperatureChannel;
	load_actual_config.voltageChannel = params.voltageChannel;
}

/*
 *	@brief Sets desired current for load circuitry.
 *	@param currentInMiliamperes Desired current expressed in milliamperes.
 */
void Load_Set_Current(const uint16_t currentInMilliamperes)
{
	setCurrent = currentInMilliamperes;
}

/*
 *	@brief Sets maximum temperature allowed in load circuitry.
 *	@param temperatureInCelcius Maximum allowed temperature expressed in degrees Celcius.
 */
void Load_Set_Max_Temperature(const uint16_t temperatureInCelcius)
{
	setMaxTemperature = temperatureInCelcius;
}

/*
 *	@brief Sets desired power for load circuitry
 */
void Load_Set_Power(const uint16_t powerInMilliwatts)
{
	setPower = powerInMilliwatts;
}

/*
 *	@brief Sets mode of load
 *  @param mode Mode to set
 */
void Load_Set_Mode(const uint8_t mode)
{
	loadMode = mode;
}

/*
 *	@brief Executes a single cycle of monitoring and regulation
 */
void Load_Run(load_params_t *paramsPtr)
{
	
}

/*
 *	@brief Gets current value at the time of function call.
 *	@return Current expressed in milliamperes. 
 */
uint16_t Load_Get_Current()
{
	uint16_t adcRaw;
	adcRaw = load_actual_config.adcReadFunction(load_actual_config.currentChannel);
	//return Compute value in milliamperes
	
}

/*
 *	@brief Gets voltage value at the time of function call.
 *	@return Voltage expressed in millivolts. 
 */
uint16_t Load_Get_Voltage()
{
	uint16_t adcRaw;
	adcRaw = load_actual_config.adcReadFunction(load_actual_config.voltageChannel);
	//return Compute value in millivolts
}

/*
 *	@brief Gets temperature value at the time of function call.
 *	@return Current expressed in celcius. 
 */
uint16_t Load_Get_Temperature()
{
	uint16_t adcRaw;
	adcRaw = load_actual_config.adcReadFunction(load_actual_config.temperatureChannel);
	//return Compute value in celcius
}

/*
 *	@brief Gets power value at the time of function call.
 *	@return Power expressed in milliwatts. 
 */
uint32_t Load_Get_Power()
{
	uint16_t voltage, current;
	uint32_t power;
	voltage = Load_Get_Voltage();
	current = Load_Get_Current();
	power = (current*voltage);
	return power;
}